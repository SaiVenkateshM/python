import os.path
filename="C:\\Users\\smaruvada\\Documents\\python\\extraction"
print(os.path.dirname(filename))
data = os.listdir(filename)
for d in data:
    dd=os.path.splitext(filename)
    if dd[1]==".log":
        fo = open(filename +"\\"+d,'r')
        print(fo.readline())