import re
import os.path
pattern =''