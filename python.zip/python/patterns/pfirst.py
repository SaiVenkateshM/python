"""This is examples for patterns-regular expression"""
import re
pattern = '\st[a-z]*|^[a-z]*'
text = 'Tom,does this text match the pattern'
# match=re.search(pattern, text)
# matches = re.finditer(pattern, text)
# if matches:
#     print('found a match!')
# for match in matches:
#     print(match.start(),match.end(),text[match.start():match.end()])
# else:
#     print('no match')

# print(re.search(pattern, text))
# if re.search(pattern, text):
#     print ("found a match!")
# else:
#     print("no match")
matches=re.findall(pattern, text,re.I)
print(matches)