# obj = [22,32,19,43]#list
# def mymap(el):
#     return 32+el*9/5
# newobj=map (mymap,obj)
# print(type(newobj))
# for i in newobj:
#     print(i)
# newobj=map(lambda el:32+el*/5,obj) // done using lambda function
#Anonymous function
'''
inline function
lambda function(to learn)
rule1 :- function should contain only 1 line
rule2 :- that 1 line should ve return statement
def sayhi(n1,n2):
    return "Hi " +n1+ " " +n2

// map list can be used for list and dictionary
'''

# data =(lambda n1,n2: "hi "+n1+" "+n2)("saurav","vicky")
# print(data)
# hello =lambda n1,n2: "Hi "+n1+" "+n2
# print(type(hello))
# print()
# t = lambda a,b: a+b
# print(t)
