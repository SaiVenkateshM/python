# """Shopping website
# sort by :-
# 1. by cost(low to high)
# 2. by cost(high to low)
# 3. rating(high to low)
# 4.discount(low to high)
# 5.discount(high to low)
# """
#
# data = [
#     {"pid": "100", "name": "iphoneXS", "cost": "110000", "rating": "5", "discount": "10000", "Catogary": "mobile"},
#     {"pid": "101", "name": "helmet", "cost": "1000", "rating": "3", "discount": "100", "Catogary": "bike accessory"},
#     {"pid": "102", "name": "oneplus7", "cost": "50000", "rating": "4", "discount": "1000", "Catogary": "mobile"},
#     {"pid": "103", "name": "gloves", "cost": "600", "rating": "2", "discount": "50", "Catogary": "bike accessory"},
#     {"pid": "104", "name": "pen", "cost": "100", "rating": "3", "discount": "5", "Catogary": "stationary"}
# ]
#
# print("Welcome to shopping website")
# print("1. press 1 for sorting product from low to high")
# print("2.press 2 for sorting product from high to low")
# print("3.press 3 for sorting product using rating high to low")
# print("4.press 4 for sorting product discount using high to low")
# print("5. Press 5 for sorting product discount using low to high")
#
# choice = int(input("Enter your choice for sorting"))
#
# fields = {1: ["cost", False], 2: ["cost", True], 3: ["rating", True], 4: ["discount", False], 5: ["discount", True]}
# if choice != 0:
#     data.sort(key=lambda ele: ele[fields[choice][0]], reverse=fields[choice][1])
#     for d in data:
#         print(d)

