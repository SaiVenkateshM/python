# def add():
#     pass
# the pass keyword is used to pass the function without executing

# print("hello world")
# def add(*args):
# print(type(args))
# print(args)
#     sum=0
#     for x in args:
#         sum+=x
#         print(args,sum)
# add(1,2)
# add(1,2,3)
# print("hello")


# Variable length keyword

# def sayhi(**vicky):
#     print(type(vicky),vicky)
# sayhi(name1='Venkatesh')
# sayhi(name1='Sachin' , name2='Saurav')
# sayhi(name1='sachin', name2='saurav', name3='Rahul')

# Generic function

# def sayhi(n1,n2,n3):
#     print("Hi "+n1+' '+n2+' '+n3)
# #
# # li=["sachin","sourav","rahul"]
# # sayhi(*li)
# li={
#     "n1":"sachin",
#     "n2":"saurav",
#     "n3":"rahul"
# }
# sayhi(**li)

# scope of the variable


# def demo():
#     data = "Hello World!"
#     print(data)
#
# demo()
# print(data)# will not work
# nameerror - Local veriable will get destroyed once the function is complete
# def demo():
#     data = "Hello World!"
# test=demo()
# print(type(test))

# functional programing
# you can pass a funcion as an argument
# you can pass as nested function
# def outer():
#     print("This is outer!")
#     def inner():
#         print("This is inner")
#     inner()
# outer()
"""
The ladder structure of coding is called lexical scoping
"""
# count =1
# def hello():
#     global count
#     print(count)
#     count += 1
#
# hello()
# hello()

# def container():
#     count =0
#     def inner():
#         nonlocal count
#         count += 1
#         print(count)
#     return inner()
#
# data=container()
# print(type(data))
# def container():
#     count =0
#     def inner():
#         nonlocal count
#         count += 1
#         print(count)
#     return inner
#
# data=container()
# print(type(data))
# data()
# data()
"""
clousure - inner function can return the outer function
"""
print("Welcome to the wallet")


def wallet(balance=10):

    def deposit():
        nonlocal balance
        num = int(input("Enter the amount to deposit in the wallet"))
        balance = num + balance
        print("The amount added to the wallet",balance)


    def withdraw():
        nonlocal balance
        num = int(input("Enter the amount to withdraw"))
        if num > balance:
            print("The amount exceeds the balance")
        else:
            balance = balance - num
            print("The amount has been withdrawn. the current balance is",balance)
    return [deposit,withdraw]
    def fundtransfer():
        nonlocal balance
        num = int(input("Enter the amount to transfer the fund to different wallet"))
        if num > balance:
            print("insufficient balance")
        else:



w1=wallet()
w2=wallet()
w1[0]()
w2[0]()
w2[1]()