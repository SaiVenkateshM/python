# complex data stucture
# t=(
    # {1,2},
    # {3,4},
    # {5,6}
    # )
# print(t[0])
# print(t[1])
# t=[
    # (1,2),
    # (3,4),
    # (5,6)
     # ]
# print(t[0])
# print(t[1][0])
# t={
    # (1,2),
    # (3,4),
    # (5,6)
     # }
# print(t)
d = {
    [1,2]:"Sachin",
    [3,4]:"Saurav",
    [5,6]:"Rahul",
    [7,8]:"Yuvraj"
}
print(d[[1,2]])
