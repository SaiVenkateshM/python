class person:
    team="india"
    def sayhi(self):
        print("hi "+self.fname+" "+self.lname)
    def __init__(o,f,l):
        o.fname=f
        o.lname=l

def demo():
    print("This is demo!")

data="Hello world"
# print("inside first :",__name__)
if __name__ == "__main__":
    print("Hello world")
    print("Hello world")