# def add(a,b):
#     return a+b
# print(add(1,2))
# print(add(1.12,2.34))
# print(add("Hello","World"))
# print(add([1,2],[3,4]))
# class person:
#     nationality = "India"  # class level encapsulation
#
#     def sayhi(self):
#         print("hi " + self.fname + "" + self.lname)
#
#     def __init__(self, fname, lname):
#         self.fname = fname
#         self.lname = lname
#     def __int__(self):
#         return len(self.fname)+len(self.lname)
#     def __str__(self):
#         return  ' {fname} {lname}'.format(**self.__dict__)
# p1=person("Sachin","Tendulkar")
# print(str(p1))
# print(p1)
"""in python if there is two or more constructor then it will point to the most recent constructor the former will not
be considered
"""
class box:
    def __init__(self,itemList):
        self.itemList=itemList
    def __str__(self): #magic fuction
        return str(self.itemList)
    def __add__(self, other):
        newitems=self.itemList+other.itemList
        b=box(newitems)
        return b
b1=box(["iten1","item2"])
b2=box(["item3","item4","item5"])
b3=b1+b2
print(b1)
print(b2)
print(b3)
