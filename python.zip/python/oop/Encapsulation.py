# import first
# obj=first.person()
# print(type(obj))
# def setVal(o,f,l):
#     o.fname=f
#     o.lname=l
# class person:
#     team = "India"  # class level encapsulation
#
#     def sayhi(p):
#         print("hi "+p.fname+" "+p.lname)
#


# obj = person()
# print(type(obj))
# obj.fname = "Sachin"  # object level encapsulation
# obj.lname = "Tendulkar"  # "" "" """
# setVal(obj,"Sachin","Tendulkar")
# print(obj.fname,obj.lname)
# obj2 = person()
# print(type(obj))
# setVal(obj2,"Rahul","Dravid")

# obj2.fname = "Rahul"  # object level encapsulation
# obj2.lname = "Dravid"
# obj2.team = "Australia"

# print(obj.fname, obj.lname, obj.team)
# print(obj2.fname, obj2.lname, obj2.team)
# print(person.team)
# print(obj.team, obj.__class__.team)
# print(obj2.team, obj2.__class__.team)
# person.sayhi(obj)
# person.sayhi(obj2)
class person:
    team = "India"  # class level encapsulation

    def sayhi(p):
        print("hi " + p.fname + " " + p.lname)

    def __init__(o, f, l):
        o.fname = f
        o.lname = l
    # def __del__(self):
    #     print("destructor called for "+self.fname+" "+self.lname)
obj= person("Sachin","tendulkar")
# obj2=person("Rahul","Dravid")
# obj.sayhi()
# obj2.sayhi()
# obj.__del__()
# obj2.__del__()
# del obj
# del obj2
#setattr(obj,"ASFVRGBFG")
#getattr,hasattr
print(person.__name__)
print(person.__module__)
print(person.__dict__)
print(person.__doc__)
#print(person.__bases__)
print(obj.__class__.__name__)
print(obj.__module__)
print(obj.__doc__)
print(obj.__dict__)