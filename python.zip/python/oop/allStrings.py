def allstrings(a):
    def inner(*args,**kwargs):
        for i in args:
            if type(i)!=str:
                print("invalid args")
                break
        else:
            for i in kwargs.values():
                if type(i)!=str:
                    print("invalid args")
                    break
            else:
                a(*args,**kwargs)
    return inner

@allstrings
def hello(name):
    print("hello "+name)
@allstrings
def sayhi(name1,name2):
    print("hi "+name1+" "+name2)
hello("sachin")
sayhi(name2="sai",name1="venkatesh")
hello(1)
sayhi(1,2)