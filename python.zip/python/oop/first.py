class product:
    def __init__(self, id, name, price, rating, discount, catogary):
        self.id = id
        self.name = name
        self.price = price
        self.rating = rating
        self.discount = discount
        self.catogary = catogary


li = [
    product("100", "iPhoneXS", "110000", "5", "10000", "Mobile"),
    product("101", "helmet", "1000", "3", "100", "bike accessory"),
    product("102", "oneplus7", "50000", "4", "1000", "mobile"),
    product("103", "gloves", "600", "2", "50", "bike accessory"),
    product("104", "pen", "100", "3", "5", "stationary")
]

print("Welcome to shopping website")
print("1. press 1 for sorting product from low to high")
print("2.press 2 for sorting product from high to low")
print("3.press 3 for sorting product using rating high to low")
print("4.press 4 for sorting product discount using high to low")
print("5. Press 5 for sorting product discount using low to high")
choice = int(input("Enter your choice for sorting"))
fields = {1: ["price", False], 2: ["price", True], 3: ["rating", True], 4: ["discount", False], 5: ["discount", True]}
if choice !=0:
    li.sort(key=lambda ele: ele.__getattribute__(fields[choice][0]), reverse=fields[choice][1])
    for d in li:
        print(d.id)
        print(d.name)
