#hierarical inheritence
# class person:
#     nationality = "India"  # class level encapsulation
#
#     def sayhi(self):
#         print("hi " + self.fname + "" + self.lname)
#
#     def __init__(self, fname, lname):
#         self.fname = fname
#         self.lname = lname
#
#
# class student(person):
#     institution = "Python university"
#     def __init__(self,fname,lname,stream):
#         person.__init__(self,fname,lname)
#         self.stream=stream
#
#     def study(obj):
#         print(obj.fname + " is studing")
#
#     # def __init__(self, fname, lname, dept, loc):
#     #     #          self.fname=fname //this can be inherited from above class
#     #     #         # self.lname=lname
#     #     person.__init__(self, fname, lname)
#     #     self.dept = dept
#     #     self.loc = loc
#
#
# e1 = student("sachin", "Tendulkar","sports")
#
# # # e1.fname = "sachin"
# # # e1.lname= "tendulkar"
# e1.study()
# e1.sayhi()
# print(e1.__dict__)
# # # print(e1.org,e1.nationality)
# #if the method is present in all the class then the program will accept according to the argument the class
# is present the class which is first
# inherited will be displayed first
class A:
    def sayhello(self):
        print("This has been inherited from class a")
class B(A):
    def sayhello(self):
        print("This has been inherited from class b")
class C(B,A):
    pass
    # def sayhello(self):
    #     print("This has been inherited from class c")
d=C()
d.sayhello()
