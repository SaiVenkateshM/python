#  class person:
#     nationality="India" #class level encapsulation
#     def sayhi(self):
#         print("hi "+self.fname+""+self.lname)
#     def __init__(self,fname,lname):
#         self.fname=fname
#         self.lname=lname
# class employee(person):
#     org="DXC"
#     def work(obj):
#         print(obj.fname+" is working")
#     def __init__(self,fname,lname,dept,loc):
#         # self.fname=fname //this can be inherited from above class
#         # self.lname=lname
#         person.__init__(self,fname,lname)
#         self.dept=dept
#         self.loc=loc
# e1=employee("sachin","Tendulkar","cricket","mumbai")
#
# # e1.fname = "sachin"
# # e1.lname= "tendulkar"
# e1.work()
# e1.sayhi()
# # print(e1.org,e1.nationality)
# print(e1.__dict__)
#multilevel inheritence
class person:
     nationality="India" #class level encapsulation
     def sayhi(self):
         print("hi "+self.fname+""+self.lname)
     def __init__(self,fname,lname):
         self.fname=fname
         self.lname=lname
class employee(person):
     org="DXC"
     def work(obj):
         print(obj.fname+" is working")
     def __init__(self,fname,lname,dept,loc):
#          self.fname=fname //this can be inherited from above class
#         # self.lname=lname
         person.__init__(self,fname,lname)
         self.dept=dept
         self.loc=loc
e1=employee("sachin","Tendulkar","cricket","mumbai")

# # e1.fname = "sachin"
# # e1.lname= "tendulkar"
e1.work()
e1.sayhi()
# # print(e1.org,e1.nationality)