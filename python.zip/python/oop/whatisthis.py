# function progaming and closure
# def outer(a):
#     print("this is outer")
#     def inner():
#         print("This is inner!")
#         # print(type(a))
#         a()
#     return inner
# @outer
# def hello():
#     print("heloow world")
# def sayhi():
#     print("hi world")
# demo1=outer(hellow)
# demo2=outer(sayhi)
# demo1()
# demo2()
# hellow=outer(hellow)
# sayhi=outer(sayhi)
# hello()
# sayhi()
"""
The wrapper function is used when you have to execute to two business logic 
@function - this is used to call the outer function, it is called decorater


"""
def outer(a):
    print("this is outer")
    def inner(*args,**kwargs):
        print("This is inner!")
        # print(type(a))
        a(*args,**kwargs)
    return inner
@outer
def hello(name):
    print("hello "+name)
@outer
def sayhi(name1,name2):
    print("hi "+name1+" "+name2)
hello("sachin")
sayhi(name2="sai",name1="venkatesh")