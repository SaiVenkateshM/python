# import first as f
from first import demo as d,person as p
d()
# print(f.data)
# p1=f.person("Sachin","Tendulkar")
# p1.sayhi()
p1=p("Sachin","Tendulkar")
p1.sayhi()
