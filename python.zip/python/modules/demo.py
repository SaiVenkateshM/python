import configparser
config = configparser.ConfigParser()
config.read('examples.ini')
print(config['bitbucket.org']['User'])
