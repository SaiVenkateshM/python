#sequence operation
#slicing
# data = "Hello Python"
# print(data[0:4]) #4th index is excluded
# print(data[6:])
#stepping
# print(data[0::2])
# print(data[0::4])
# print(data[0::-1])
# print(data[:5:-1])
# print(data[4:0:-1])
# print(data[4::-1])
# print(data[::-1])
# data = 1,2,2.3,True,None,"Hello"
# print(type(data))
# print(data[0])
# print(data[-1])
# print(data[::-1])
# print(data[-1][::-1])
# data[1] = False
# data = 1,
# data=(1,)
# print(type(data))
# sequence
# s1 = {True,None,'Hello',1,'Sachin'}#set
# print(type(s1))
# print(s1)
# s1 = {1,2,3,4}
# s2 = {3,4,5,6}
# s3 = {1,2}
# print(s1|s2) #union
# print(s1&s2) #intersection
# print(s1-s2) #difference
# print(s2-s1) #difference
# print(s3<s1) #issubset
# dictionary
# s1 = {
# 'fname':"Sachin",
# 'lname':"Tendulkar"
# }
# s1['team']="India"
# print(type(s1))
# print(s1['fname'])
# print(s1['lname'])
# print(s1['team'])















