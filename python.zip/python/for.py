# data = "HelloPython"
# for d in data:
#     print(d)
# data =set("HelloPython")
# print(type(data))
# for d in data:
#     print(d)
# data = range(10)
# print(type(data))
# for d in data:
#     print(d)
# num=int(input("Enter number: "))
# for i in range(2,num) :
#     if num%i==0:
#         print("Not prime!")
#         break
# else:
#     print("Prime")
# n = 3
# for i in range(0, n+1):
#     print(i*"*")
# n = 3
# for i in range(n+1,0):
#     print(i*"*")
def sayhello(name1,name2,name3):
    print("hi "+name1+" "+name2+" "+name3)
# sayhello("Sachin","Saurav","Rahul")
print(type(sayhello("Sachin","Saurav","Rahul")))