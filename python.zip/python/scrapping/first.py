from requests import get
from bs4 import BeautifulSoup
url ='https://www.moneycontrol.com'
response = get(url)
soup = BeautifulSoup(response.text,'html.parser')
"""lxml"""
# print(type(soup))
# print(soup.html.head.meta)
print(type(soup))
tables=soup.find_all('table',class_="rhsglTbl")
# links=soup.find_all('table',class_="rhsglTbl")
# print(links)
# links=soup.find_all('a',attrs={'id':'google_ads_iframe_/1039154/Moneycontrol/MC_HP/MC_HP_210x70_Left_0__container__'})
# print(links)
for table in tables:
    links=table.find_all('a')
    print(links)