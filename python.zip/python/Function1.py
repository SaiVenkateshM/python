# a,b=int(input()),int(input())
# a,b=(b,a)
# print(a,b)
# astring = "Hello World!"
# print(len(astring))
# print(astring.index())
# print(astring.index('o',5))
# print(astring.index('o',5,8))
# print(astring.count("l"))
# print(astring.upper())
# print(astring.lower())
# print(astring.startswith("Hello"))
# print(astring.endswith("d!"))
# words = (astring.split(" "))
# print(words)
# print(astring.find('o'))
# print(astring.find('o',5))
# print(astring.find(('o',5,8)))
# print(astring.replace("World", "Python"))
# data ="i am a {0} from {1}"
# sub1='string'
# lang='Python'
# print(data.format(sub1,lang))
# temp='''Hello {fname} {lname} welcome to {city}'''
# dataString = temp.format(fname="venkatesh",lname="maruvada",city="raipur")
# print(dataString)
# l=['a','b','c','d','e']
# print(len(l))
# print(max(l))
# print(min(l))
# l.append('g')
# print(l)
# l2 = ['h','i','j','k']
# l.extend(l2)
# print(l)
# l.insert(2,'z')
# print(l)
# print(l.pop(2))
# print(l)
# print(l.pop())
#
# el ={ {"fname": "sachin",
#        "lname":"tendulkar",
#        "city":"bilaspur"
#        },
#      {
#    "fname": "rahul",
#     "lname": "Dravid"
#     "city": "mumbai"
#      },
# {
    "fname"
}
}
"""
sorting ,filter
"""
# el=[
#     {"team":"India","fname":"Sachin","lname":"Tendulkar"},
#     {"team":"india","fname":"sourav","lname":"gaungaly"},
# ]
# def myfilter(el):
#         return el["team"]=="India"
# newobj=filter(myfilter,obj)
# print(type(newobj))
# for i in newobj:
#     print(' {fname} {lname})'.format(**i))
"""
# 
# obj.sort(key=lambda el:el[
# newobj=map(lambda el:32+el*/5,obj)
# """