class NameNotFound(Exception):
    def __init__(self,msg="name not found"):
        Exception.__init__(self,msg)
try:
    names=["Sachin","Sourav","Rahul"]
    name=input("Enter name: ")
    if name not in names:
        # raise Exception("name not found!")
        raise NameNotFound
    print("Welcome "+name)
except NameNotFound as e:
    print(e)
# except (ZeroDivisionError,ValueError) as e:
#     print("please enter non zero numeric value")
except Exception as e:
    print("Generic handler!!",e)

print("Some other important task")