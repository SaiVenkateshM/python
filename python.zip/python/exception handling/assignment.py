data: {
    "Sachin":"icc",
    "saurav":"bcci",
    "venkatesh":"dxc"
}
a=input("Enter name")
b=input("Enter password")

class InvalidUser(Exception):
    def __init__(self,msg="Invalid user"):
        Exception.__init__(self,msg)
