# # marks=int(input('Enter marks'))
# # if marks>=0 and marks<=100:
# # # print("valid")
# # # else:
# # #     print("Invalid")
# # #
# # # if marks<0 or marks>100:
# # #     print("Invalid")
# # # else:
# # #     print("valid")
# i=0
# while i<=10:
#     print(i)
#     i+=1
# else:
#     print("Loop exhausted!")
#
# num= int(input('Enter number'))
# i=1
# while i<=num:
#     if num % i ==0:
#         print(i)
#     i+=1
