import os
# print(os.listdir("C:\\Users\\smaruvada\\Documents\\python"))
# print(os.getcwd())
# os.chdir('..')
# print(os.getcwd())
# filename="demo.txt"
#os.makedirs("test/multiple/levels")
# os.removedirs("test/multiple/levels")
# os.remove(filename)
print(os.name)
stat = os.stat(first.py)
print(stat)
print(stat.st_size)
print(stat.st_atime)
