try:
    a=int(input("Enter number"))
    b=int(input("Enter number"))
    division=a/b
    print("data :",division)
except ZeroDivisionError as e:
    print(e)
except ValueError as e:
    print(e)
except Exception as e:
    print("generic handler")
dprint("Some other important task")