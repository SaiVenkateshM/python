import os.path
filename="C:\\Users\\smaruvada\\Documents\\python\\files\\demo.txt"
# print(os.path.split(filename))
# print("splitext", "=>", os.path.splitext(filename))
# print(os.path.dirname(filename))
# print(os.path.basename(filename))
# print(os.path.exists(filename))
# print(os.path.isabs(filename))
# print(os.path.isdir(filename))
print(os.environ['PYTHONPATH'])
os.environ['User']="root"
varPath='usr/$User/appdata'
actPath=os.path.expandvars(varPath)
print(actPath)